"use strict";

const x = 3;
x++;
--x;
x = 4;
x *= 2;
x /= 2;

if (true) {
    let x = 3;
    x++;
}
