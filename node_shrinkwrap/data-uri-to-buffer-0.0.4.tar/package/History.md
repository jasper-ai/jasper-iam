
0.0.4 / 2015-06-29
==================

  * package: update "mocha" to v2
  * package: add RFC to the "keywords" section
  * travis: test node v0.8, v0.10, and v0.12
  * README: use SVG for Travis-CI badge
  * test: more tests

0.0.3 / 2014-01-08
==================

  * index: fix a URI with a comma in the data portion

0.0.2 / 2014-01-08
==================

  * index: use unescape() instead of decodeURIComponent()
  * test: add more tests from Mozilla

0.0.1 / 2014-01-02
==================

  * add `README.md`
  * index: default the `charset` property to "US-ASCII"
  * default encoding is "ascii"
  * default `type` to "text/plain" when none is given
  * initial commit
