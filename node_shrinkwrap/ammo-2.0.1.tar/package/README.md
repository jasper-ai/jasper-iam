#ammo

HTTP Range processing utilities.

[![Build Status](https://secure.travis-ci.org/hapijs/ammo.png)](http://travis-ci.org/hapijs/ammo)

Lead Maintainer - [Eran Hammer](https://github.com/hueniverse)
