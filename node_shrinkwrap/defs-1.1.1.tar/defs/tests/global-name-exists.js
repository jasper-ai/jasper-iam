"use strict";
// unclear on whether it should be an error to redefine global names on top-level
// for now, we allow it
let name = "asdf";
let console = 3;
let undefined = 5;
