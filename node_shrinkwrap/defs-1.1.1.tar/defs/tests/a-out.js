"use strict";
function fn() {
    var x = 3;
    if (true) {
        var x$0 = 4;
        console.log(x$0);
    }
    console.log(x);
}
