"use strict";
let x = x; // error
let y = 1, z = y; // ok
let a = b, b = 1; // error
