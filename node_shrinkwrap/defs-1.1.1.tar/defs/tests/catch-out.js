"use strict";

var x = 1;
{
    var x$0 = 3;
    try {
    } catch (x) {
        console.log(x);
    }
}
