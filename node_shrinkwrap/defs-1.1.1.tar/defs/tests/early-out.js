"use strict";
var x;
function named_fn(a, b) {
    var unique = 1;
    for (x = 3; x < 10; x++) {
        var i = 1;
        var y$0 = 2;
        console.log(y$0);
    }
    for (var x$0 in [1,2,3,4,5]) {
        var y$1 = x$0;
        console.log(y$1);
    }
    var y,z;
}
named_fn();
