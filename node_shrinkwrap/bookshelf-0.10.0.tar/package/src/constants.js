export const PIVOT_PREFIX = '_pivot_';
