#b64

Base64 streaming encoder and decoder

[![Build Status](https://secure.travis-ci.org/hapijs/b64.png)](http://travis-ci.org/hapijs/b64)

Lead Maintainer - [Wyatt Preul](https://github.com/geek)
