var arr = [1, 2, 3];
var i = 0;

for (var i$0 = 0; i$0 < arr.length; i$0++) {
    arr[i$0];
    i$0[i$0];
}
