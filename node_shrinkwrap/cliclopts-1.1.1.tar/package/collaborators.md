## Collaborators

cliclopts is only possible due to the excellent work of the following collaborators:

<table><tbody><tr><th align="left">maxogden</th><td><a href="https://github.com/maxogden">GitHub/maxogden</a></td></tr>
<tr><th align="left">finnp</th><td><a href="https://github.com/finnp">GitHub/finnp</a></td></tr>
</tbody></table>
