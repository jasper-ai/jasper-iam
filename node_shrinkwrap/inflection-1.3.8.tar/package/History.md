# History

## 1.3.8 / 2014-07-03
- [others] syntax tuning



## 1.3.7 / 2014-06-25

- [refactoring] Adopt UMD import to work in a variety of different situations
- [update packages] should->4.0.4



## 1.3.6 / 2014-06-07

- [bug fix] Rearrange rules. `movies` -> `movy`



## 1.3.5 / 2014-02-12

- Unable to publsih v1.3.4 therefore jump to v1.3.5



## 1.3.4 / 2014-02-12

- [update packages] should->3.1.2
- [refactoring] Use `mocha` instead of hard coding tests



## 1.3.3 / 2014-01-22

- [update packages] should->3.0.1
- Added brower.json



## 1.3.2 / 2013-12-12

- [update packages] node.flow->1.2.3



## 1.3.1 / 2013-12-12

- [refactoring] Support `Requirejs`



## 1.3.0 / 2013-12-11

- [refactoring] Move `var` out of loops
- [refactoring] Change the way `camelize` acts to mimic 100% `Rails ActiveSupport Inflector camelize`



## 1.2.7 / 2013-12-11

- [new feature] Added transform, thnaks to `luk3thomas`
- [update packages] should->v2.1.1



## 1.2.6 / 2013-05-24

- [bug fix] Use instance instead of `this`



## 1.2.5 / 2013-01-09

- [refactoring] Allow all caps strings to be returned from underscore



## 1.2.4 / 2013-01-06

- [bug fix] window obj does not have `call` method



## 1.2.3 / 2012-08-02

- [bug fix] Singularize `status` produces `statu`
- [update packages] should->v1.1.0



## 1.2.2 / 2012-07-23

- [update packages] node.flow->v1.1.3 & should->v1.0.0



## 1.2.1 / 2012-06-22

- [bug fix] Singularize `address` produces `addres`



## 1.2.0 / 2012-04-10

- [new feature] Browser support
- [update packages] node.flow->v1.1.1



## 1.1.1 / 2012-02-13

- [update packages] node.flow->v1.1.0



## 1.1.0 / 2012-02-13

- [update packages] node.flow->v1.0.0
- [refactoring] Read version number from package.json



## 1.0.0 / 2012-02-08

- Remove make file
- Add pluralize rules
- Add pluralize tests
- [refactoring] Use object.jey instead of for in



## 0.0.1 / 2012-01-16

- Initial release
