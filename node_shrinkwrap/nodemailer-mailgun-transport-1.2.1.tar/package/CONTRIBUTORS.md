Because opensource is better when done together, if you would like to be acknowledged for your contribution feel free to modify this file and add yourself to the list of contributors to the project.
I promise there is no easter egg :)

#Contributors to this project in no particular order

```
mindmelting
MaffooBristol
giladbeeri 
rick4470 
MetaMemoryT 
RichardLitt 
wmcmurray 
ViktorPeleshko 
trueter 
JoshWillik 
albertovasquez
```
