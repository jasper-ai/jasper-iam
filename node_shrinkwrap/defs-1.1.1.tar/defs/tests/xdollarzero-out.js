"use strict";
var x$0;
var x;
{ var x$1; }
