module.exports = function noop () {}
