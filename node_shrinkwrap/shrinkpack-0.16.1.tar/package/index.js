// modules
var analyse = require('./src/analyse');
var update = require('./src/update');

// public
module.exports = {
  analyse: analyse,
  update: update
};
