# jasper-hapi-healthcheck

[![Join the chat at https://gitter.im/jasper-ai/jasper-hapi-healthcheck](https://badges.gitter.im/jasper-ai/jasper-hapi-healthcheck.svg)](https://gitter.im/jasper-ai/jasper-hapi-healthcheck?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Hapi.js plugin - healthcheck endpoint used to verify service availability

[![Circle CI](https://circleci.com/gh/jasper-ai/jasper-hapi-healthcheck.svg?style=svg)](https://circleci.com/gh/jasper-ai/jasper-hapi-healthcheck)
[![Dependency Status](https://dependencyci.com/github/jasper-ai/jasper-hapi-healthcheck/badge)](https://dependencyci.com/github/jasper-ai/jasper-hapi-healthcheck)
[![codecov](https://codecov.io/gh/jasper-ai/jasper-hapi-healthcheck/branch/master/graph/badge.svg)](https://codecov.io/gh/jasper-ai/jasper-hapi-healthcheck)
