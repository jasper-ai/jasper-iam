console.warn(
  "The regenerator/runtime-module module is deprecated; " +
    "please import regenerator-runtime instead."
);

module.exports = require("regenerator-runtime");
