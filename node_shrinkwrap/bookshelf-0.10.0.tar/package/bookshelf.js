/**
 * (c) 2013-present Tim Griesser
 * Bookshelf may be freely distributed under the MIT license.
 * For all details and documentation:
 * http://bookshelfjs.org
 *
 */
module.exports = require('./lib/bookshelf').default;
