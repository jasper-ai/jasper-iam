var arr = [1, 2, 3];
var i = 0;

for (let i = 0; i < arr.length; i++) {
    arr[i];
    i[i];
}
