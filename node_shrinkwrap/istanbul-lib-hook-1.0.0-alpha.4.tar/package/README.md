istanbul-lib-hook
=================

[![Build Status](https://travis-ci.org/istanbuljs/istanbul-lib-hook.svg?branch=master)](https://travis-ci.org/istanbuljs/istanbul-lib-hook)

Hooks for require, vm and script used in istanbul
