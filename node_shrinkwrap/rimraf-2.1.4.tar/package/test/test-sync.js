var rimraf = require("../rimraf")
  , path = require("path")
rimraf.sync(path.join(__dirname, "target"))
