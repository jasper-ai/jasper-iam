"use strict";

var x = 3;
if (1) {
    var x = 4;
}
function x() {
}
