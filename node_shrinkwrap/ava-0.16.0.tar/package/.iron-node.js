module.exports = {
	app: {
		openDevToolsDetached: true,
		hideMainWindow: true
	},
	workSpaceDirectory: function () {
		return __dirname;
	}
};
