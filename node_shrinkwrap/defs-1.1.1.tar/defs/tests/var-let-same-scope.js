"use strict";
var x = 4;
let x = 5;

let y = 6;
var y = 7;
