module.exports = function flatstr(s) {
  Number(s)
  return s
}