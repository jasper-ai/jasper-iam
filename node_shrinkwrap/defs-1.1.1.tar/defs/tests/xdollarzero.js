"use strict";
var x$0;
var x;
{ let x; }
