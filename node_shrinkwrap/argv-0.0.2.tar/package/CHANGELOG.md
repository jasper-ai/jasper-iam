## v0.0.2

* Transfering help and version option after calling clear


## v0.0.1

Initial Release
