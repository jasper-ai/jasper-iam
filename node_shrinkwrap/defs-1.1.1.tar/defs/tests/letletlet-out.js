"use strict";
var x;
{ var x$0; }
{ var x$1; }
{ var x$2; }

{ var y; }
{ var y$0; }
{ var y$1; }

{ var z; { var z$0; }}
{ var z$1; }
{ var z$2; { var z$3; { var z$4; }}}
