"use strict";
// unclear on whether it should be an error to redefine global names on top-level
// for now, we allow it
var name = "asdf";
var console = 3;
var undefined = 5;
