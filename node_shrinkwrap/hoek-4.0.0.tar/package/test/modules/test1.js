'use strict';

exports.x = 1;
