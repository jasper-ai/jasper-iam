# jasper-hapi-metrics

[![Join the chat at https://gitter.im/jasper-ai/jasper-hapi-metrics](https://badges.gitter.im/jasper-ai/jasper-hapi-metrics.svg)](https://gitter.im/jasper-ai/jasper-hapi-metrics?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Hapi.js plugin - metrics endpoint used to verify process/server metrics

[![Circle CI](https://circleci.com/gh/jasper-ai/jasper-hapi-metrics.svg?style=svg)](https://circleci.com/gh/hapi-ai/jasper-auth-jasper)
[![Dependency Status](https://dependencyci.com/github/jasper-ai/jasper-hapi-metrics/badge)](https://dependencyci.com/github/jasper-ai/jasper-hapi-metrics)
[![codecov](https://codecov.io/gh/jasper-ai/jasper-hapi-metrics/branch/master/graph/badge.svg)](https://codecov.io/gh/jasper-ai/jasper-hapi-metrics)
