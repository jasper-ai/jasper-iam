console.warn(
  "The regenerator/runtime module is deprecated; " +
    "please import regenerator-runtime/runtime instead."
);

module.exports = require("regenerator-runtime/runtime");
