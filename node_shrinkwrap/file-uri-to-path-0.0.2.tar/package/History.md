
0.0.2 / 2014-01-27
==================

  * index: invert the path separators on Windows

0.0.1 / 2014-01-27
==================

  * initial commit
