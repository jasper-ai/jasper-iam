"use strict";
var x;
{ let x; }
{ let x; }
{ let x; }

{ let y; }
{ let y; }
{ let y; }

{ let z; { let z; }}
{ let z; }
{ let z; { let z; { let z; }}}
