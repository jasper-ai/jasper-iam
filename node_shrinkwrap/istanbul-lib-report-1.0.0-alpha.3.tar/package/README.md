istanbul-lib-report
===================

[![Build Status](https://travis-ci.org/istanbuljs/istanbul-lib-report.svg?branch=master)](https://travis-ci.org/istanbuljs/istanbul-lib-report)

Core reporting utilities for istanbul. Docs to follow.

