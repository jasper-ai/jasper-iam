#statehood

HTTP State Management Utilities.

[![Build Status](https://secure.travis-ci.org/hapijs/statehood.png)](http://travis-ci.org/hapijs/statehood)

Lead Maintainer - [Eran Hammer](https://github.com/hueniverse)
