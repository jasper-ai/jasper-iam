# CHANGELOG

### 1.0.1
- update readme
- add changelog (so meta...)

### 1.0.2
- fix circle ci build

### 1.1.0
- add support for request timeouts

### 1.1.3
- update readme, showcase better examples
