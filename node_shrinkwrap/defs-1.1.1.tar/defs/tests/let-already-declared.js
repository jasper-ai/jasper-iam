"use strict";

var x = 3;
let x = 4;
const x = 5;

function f() {
    let f = 1;
    function f() {
    }

    const y = 1;
    if (1) {
        var y;
    }
}
