istanbul-lib-source-maps
========================

[![Build Status](https://travis-ci.org/istanbuljs/istanbul-lib-source-maps.svg)](https://travis-ci.org/istanbuljs/istanbul-lib-source-maps)

Source map support for istanbul. Extremely immature at this point.
