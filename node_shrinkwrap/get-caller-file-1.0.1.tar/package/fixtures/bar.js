'use strict';
var foo = require('./foo.js');

module.exports = function() {
  return foo();
};
