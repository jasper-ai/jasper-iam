Include the following information with your issue:

1) Nodemailer version you are having problems with (eg. v1.3.7)
2) Node.js version you are using (run `node -v` to see it, eg v5.5.0)
3) Your operating system (eg. Windows 10, Ubuntu 14.04 etc.)
4) If possible, include a minimal test case that can be used to verify your issue (link to a gist would be great!)

If you are having problems with Gmail, then make sure you have
read this post before filing your issue: http://nodemailer.com/using-gmail/
